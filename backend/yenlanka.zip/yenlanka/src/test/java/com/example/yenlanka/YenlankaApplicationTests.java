package com.example.yenlanka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YenlankaApplicationTests {

	@Test
	void contextLoads() {
	}

}
